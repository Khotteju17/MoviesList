//
//  PopularMoviesTableViewCell.swift
//  NowPlayingMoviesApp
//
//   Created by Tejashree on 30/04/23.
//

import UIKit

class PopularMoviesTableViewCell: UITableViewCell {

    @IBOutlet var movieTitleLabel: UILabel!
    @IBOutlet var movieRatingLabel: UILabel!
    @IBOutlet var movieReleaseDate: UILabel!
    @IBOutlet var moviePosterImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
