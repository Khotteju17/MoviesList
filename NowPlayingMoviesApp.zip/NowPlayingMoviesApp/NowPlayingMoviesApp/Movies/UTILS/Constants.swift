//
//  Constants.swift
//  NowPlayingMoviesApp
//
//   Created by Tejashree on 30/04/23.
//

import Foundation

enum Constants: String {

    case POPULAR_MOVIES_BASE_URL = "https://api.themoviedb.org/3/movie/now_playing?page=" //"https://api.themoviedb.org/3/movie/popular?page="
    case TMDB_API_KEY = "&language=en-US&api_key=34c902e6393dc8d970be5340928602a7"
    case MOVIE_POSTER_PATH = "https://image.tmdb.org/t/p/w500/"
}

var MAX_PAGE = 1

